# FoodApp_UI

Screen design of a Food App Flutter.

Design credit - https://dribbble.com/shots/5137623-Food-App-Homepage-Concept/attachments/1133457

How do I code this - https://youtu.be/bmmTY2lHaks

## Screenshot:

![screenshot_20181029-042847](https://user-images.githubusercontent.com/8137504/47731741-bc723900-dc8a-11e8-9a80-4a744a12dc4c.png)
